package com.lihuaxiaomao.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "image_albums")
data class ImageAlbum(
    @PrimaryKey
    val id: String,
    val title: String,
    val coverImagePath: String?,
    val imagePaths: List<String>,
    val sortOrder: Int,
    val createdAt: Date,
    val updatedAt: Date
)