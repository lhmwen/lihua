package com.lihuaxiaomao.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lihuaxiaomao.app.data.database.AppDatabase
import com.lihuaxiaomao.app.data.entity.InterviewGroup
import com.lihuaxiaomao.app.data.entity.InterviewQuestion
import com.lihuaxiaomao.app.data.repository.InterviewRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class InterviewViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = InterviewRepository(
        database.interviewGroupDao(),
        database.interviewQuestionDao()
    )

    private val _interviewGroups = MutableStateFlow<List<InterviewGroup>>(emptyList())
    val interviewGroups: StateFlow<List<InterviewGroup>> = _interviewGroups.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getAllInterviewGroups().collect {
                _interviewGroups.value = it
            }
        }
    }

    fun createInterviewGroup(name: String) {
        viewModelScope.launch {
            repository.createInterviewGroup(name)
        }
    }

    fun createQuestion(question: String, answer: String, groupId: String) {
        viewModelScope.launch {
            repository.createQuestion(question, answer, groupId)
        }
    }

    fun updateInterviewGroup(group: InterviewGroup) {
        viewModelScope.launch {
            repository.updateInterviewGroup(group)
        }
    }

    fun deleteInterviewGroup(group: InterviewGroup) {
        viewModelScope.launch {
            repository.deleteInterviewGroup(group)
        }
    }
}