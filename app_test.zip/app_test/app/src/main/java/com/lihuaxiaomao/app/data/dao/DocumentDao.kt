package com.lihuaxiaomao.app.data.dao

import androidx.room.*
import com.lihuaxiaomao.app.data.entity.Document
import kotlinx.coroutines.flow.Flow

@Dao
interface DocumentDao {
    @Query("SELECT * FROM documents ORDER BY sortOrder ASC")
    fun getAllDocuments(): Flow<List<Document>>

    @Query("SELECT * FROM documents WHERE id = :id")
    suspend fun getDocumentById(id: String): Document?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(document: Document)

    @Update
    suspend fun updateDocument(document: Document)

    @Delete
    suspend fun deleteDocument(document: Document)

    @Query("UPDATE documents SET sortOrder = :sortOrder WHERE id = :id")
    suspend fun updateDocumentSortOrder(id: String, sortOrder: Int)
}