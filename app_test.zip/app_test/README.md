# 狸花小猫 Android 应用

这是一个基于 Android Jetpack Compose 开发的多功能应用，包含笔记管理、面试题库、文档管理和图片相册功能。

## 功能特性

### 📝 笔记管理
- 支持笔记分组管理
- 无分组笔记支持
- 创建、编辑、删除笔记
- 笔记排序功能

### 🎯 面试题库
- 面试题分组管理
- 问题和答案管理
- 支持创建、编辑、删除面试题
- 面试题排序功能

### 📄 文档管理
- 文档导入功能
- 文档分类管理
- 支持多种文档格式

### 🖼️ 图片相册
- 图片导入功能
- 相册管理
- 图片浏览功能

## 技术栈

- **UI框架**: Jetpack Compose
- **架构**: MVVM + Repository Pattern
- **数据库**: Room Database
- **导航**: Navigation Compose
- **依赖注入**: 手动依赖注入
- **异步处理**: Kotlin Coroutines + Flow

## 项目结构

```
app/src/main/java/com/lihuaxiaomao/app/
├── data/
│   ├── entity/          # 数据实体
│   ├── dao/             # 数据访问对象
│   ├── database/        # 数据库配置
│   ├── repository/      # 数据仓库
│   └── converter/       # 类型转换器
├── ui/
│   ├── screen/          # 界面组件
│   ├── viewmodel/       # 视图模型
│   └── theme/           # 主题配置
├── MainActivity.kt      # 主Activity
└── MainApp.kt          # 应用导航
```

## 构建和运行

### 前置要求
- Android Studio Arctic Fox 或更高版本
- JDK 11 或更高版本
- Android SDK API 34
- Gradle 8.0+

### 构建步骤

1. **克隆项目**
   ```bash
   git clone <repository-url>
   cd app_test
   ```

2. **使用 Android Studio**
   - 打开 Android Studio
   - 选择 "Open an existing project"
   - 选择项目根目录
   - 等待 Gradle 同步完成
   - 点击 "Run" 按钮或使用快捷键 Shift+F10

3. **使用命令行**
   ```bash
   # 构建 Debug 版本
   ./gradlew assembleDebug
   
   # 安装到设备
   ./gradlew installDebug
   
   # 运行测试
   ./gradlew test
   ```

### 模拟器配置
- 推荐使用 API 34 (Android 14)
- 最低支持 API 24 (Android 7.0)
- 推荐内存: 4GB+

## 应用截图

### 主界面
- 底部导航栏包含四个主要功能模块
- Material Design 3 设计风格
- 支持深色/浅色主题

### 笔记功能
- 笔记组列表显示
- 无分组笔记管理
- 笔记详情页面
- 创建和编辑对话框

### 面试题功能
- 面试题组管理
- 问答形式展示
- 答案展开/收起功能

## 开发说明

### 数据库设计
- 使用 Room 数据库
- 支持数据迁移
- 类型转换器支持复杂数据类型

### UI 设计
- 基于 Material Design 3
- 响应式布局
- 自定义主题色彩

### 状态管理
- 使用 StateFlow 和 Compose State
- ViewModel 管理 UI 状态
- Repository 模式管理数据

## 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 贡献

欢迎提交 Issue 和 Pull Request！

## 联系方式

如有问题，请联系开发者。